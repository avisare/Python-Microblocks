from .shared_memory_client import SharedMemoryClient
from transportation_protocols.transportation_protocols_exception import ControlMethodNotFound
from transportation_protocols.connection_factory import ConnectionFactory
import parse_config
import SharedMemoryWrapper


def get_value_if_exist(dictionary, key):
    if key in dictionary.keys():
        return dictionary[key]
    return None


def get_shared_memory(control_method=None, mode=None, connection_type=None, timeout_seconds=None, buffer_size_bytes=None, responder_port=None, responder_ip=None, local_port=None):
    """
    function return shared memory object, based on the parameters
    :param control_method: the control method, local or remote
    :param mode: the mode of the connection, client/server/responder/initiator/strict
    :param connection_type: the connection type, TCP/UDP
    :param timeout_seconds: number of seconds until the object will exit from the receive method
    :param buffer_size_bytes: number of bytes get when calling to receive method
    :param responder_port: the port of the responder
    :param responder_ip: the ip of the responder
    :param local_port: the local port
    all the parameters are optional, because any type of connnection needs
    different parameters (and when control=local all the parameters are useless)
    :return: the shared memory object created based on the parameters
    """
    if control_method is None:
        control_method = parse_config.config_dictionary["control"]
        mode = get_value_if_exist(parse_config.config_dictionary, "mode")
        connection_type = get_value_if_exist(parse_config.config_dictionary, "connection_type")
        timeout_seconds = get_value_if_exist(parse_config.config_dictionary, "timeout_seconds")
        buffer_size_bytes = get_value_if_exist(parse_config.config_dictionary, "buffer_size_bytes")
        responder_port = get_value_if_exist(parse_config.config_dictionary, "responder_port")
        responder_ip = get_value_if_exist(parse_config.config_dictionary, "responder_ip")
        local_port = get_value_if_exist(parse_config.config_dictionary, "local_port")
    if control_method == "remote":
        return SharedMemoryClient(ConnectionFactory.get_connection(mode, connection_type, timeout_seconds, buffer_size_bytes, responder_port, responder_ip, local_port))
    elif control_method == "local":
        return SharedMemoryWrapper
    else:
        raise ControlMethodNotFound(control_method)


def initialize_shared_memory(shared_memory_object):
    """
    function initalize the shared memory SMT_Init and creating all the
    topics from the configuration file
    :param shared_memory_object: the object (the module if local or client of remote)
    :return: None
    """
    shared_memory_object.SMT_Init()
    topics_to_init = parse_config.config_dictionary["topics"]
    for topic in topics_to_init:
        shared_memory_object.SMT_CreateTopic(topic)
