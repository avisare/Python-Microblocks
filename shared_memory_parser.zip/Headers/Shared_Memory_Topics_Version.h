﻿/////////////////////////////////////////////////////////////////////////////
// File Name:  Shared_Memory_Topics_Version.h
//
// Description: Hydra_Topics Version
//
// Copyright (c) 2021 (year of creation) Rafael Ltd. All rights reserved.
/////////////////////////////////////////////////////////////////////////////

#ifndef SHARED_MEMORY_TOPICS_VERSION_H
#define SHARED_MEMORY_TOPICS_VERSION_H

#define SHARED_MEMORY_TOPICS_VERSION "1.0.0.3"

#endif // SHARED_MEMORY_TOPICS_VERSION_H

// --- END OF FILE ---
